package net.lax1dude.eaglercraft.adapter.teavm;

import org.teavm.jso.JSObject;

public interface WebGLVertexArray extends JSObject {
}
