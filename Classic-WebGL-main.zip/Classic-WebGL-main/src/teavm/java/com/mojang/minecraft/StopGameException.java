package com.mojang.minecraft;

public class StopGameException extends Error
{
	private static final long serialVersionUID = 1L;
}
