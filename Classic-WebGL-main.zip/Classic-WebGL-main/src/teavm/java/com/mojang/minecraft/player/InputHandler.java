package com.mojang.minecraft.player;

public class InputHandler
{
	public float xxa = 0.0F;
	public float jumping = 0.0F;
	public boolean yya = false;

	public void updateMovement()
	{
	}

	public void resetKeys()
	{
	}

	public void setKeyState(int key, boolean state)
	{
	}
}
